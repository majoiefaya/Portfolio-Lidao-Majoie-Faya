<!doctype html>
<html>

<head>
  <title>403: Доступ запрещён</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width" />
  <link href="/static-fornex-custom/css/base.css" rel="stylesheet" />
</head>

<body>
  <header class="header header-bg">
    <div style="background-image: url('/static-fornex-custom/img/prlx-bg-main.png');" class="header-bg-image hdn-lg"></div>
    <div class="wrap">
      <div class="header-inner">
        <div class="table">
          <div class="left-nav table-cell-md">
            <a href="https://fornex.com/"><img src="/static-fornex-custom/img/logo.png"
                srcset="/static-fornex-custom/img/logo@2x.png 2x" class="logo logo-light" /></a><a
              href="https://fornex.com/"><img src="/static-fornex-custom/img/logo-dark.png"
                srcset="/static-fornex-custom/img/logo-dark@2x.png 2x" class="logo logo-dark" /></a>
          </div>
          <div class="center-nav table-cell-md hdn-lg">
            <div class="slogan-note">
              Надежные VPS, выделенные серверы, хостинг и домены
            </div>
          </div>
          <div class="table-cell-md ta-r hdn-lg">
            <a href="https://fornex.com/" style="color: #fff"><span class="border border-2x">Перейти на сайт
              </span></a>
          </div>
        </div>
      </div>
    </div>
  </header>
  <div class="table blocked-page">
    <div class="table-cell-md">
      <div class="wrap">
        <div class="parts-row parts-2 parts-divide parts-lg-collapse">
          <div class="col-item hdn-lg">
            <img src="/static-fornex-custom/img/icons/403.png" alt="403 image" />
          </div>
          <div class="col-item">
            <div class="alert-title">Доступ запрещён</div>
            Причиной проблемы может быть отсутствие индексного файла в каталоге сайта или неправильные права доступа на файлы и папки.
            <span class="ttl">Полезные ссылки</span>
            <div class="parts-row parts-2 parts-md-collapse">
              <div class="col-item">
                <div class="nav-list">
                  <ul>
                    
                    <li>
                      <a href="https://fornex.com/help/hosting-403-forbidden/">Почему я вижу эту страницу</a>
                    </li>
                    
                    <li>
                      <a href="https://fornex.com/help/transfer-site/">Перенос сайтов</a>
                    </li>
                    
                  </ul>
                </div>
              </div>
              <div class="col-item">
                <div class="nav-list">
                  <ul>
                    <li>
                      <a href="https://fornex.com/my/tickets/">Техническая поддержка</a>
                    </li>
                    <li>
                      <a href="https://fornex.com/help/faq/">FAQ</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <hr />
            <span class="ttl">Услуги от fornex.com</span>
            <div class="parts-row parts-6 parts-md-collapse">
              <div class="col-item part-6x3">
                <div class="nav-list">
                  <ul>
                    <li>
                      <a href="https://fornex.com/dedicated/">Выделенные серверы</a>
                    </li>
                    <li>
                      <a href="https://fornex.com/ssd-vps/">SSD VPS</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-item part-6x2">
                <div class="nav-list">
                  <ul>
                    <li>
                      <a href="https://fornex.com/ssd-hosting/">SSD хостинг</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-item">
                <div class="nav-list">
                  <ul>
                    <li>
                      <a href="https://fornex.com/backup/">Бэкап</a>
                    </li>
                    <li>
                      <a href="https://fornex.com/vpn/">VPN</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
    var links = document.getElementsByTagName("a");
    for (var i = 0; i < links.length; i++) {
      links[i].href += "?from=blocked-" + location.hostname;
    }
  </script>
</body>

</html>